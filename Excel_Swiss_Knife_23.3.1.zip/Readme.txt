Excel Swiss Knife
CopyRight (c) 2017-23, Enrico Galli

Grazie per aver scaricato Excel Swiss Knife! 
Seguono alcune brevi note sul programma e il suo utilizzo. 
Per ogni ulteriore informazione e per scaricare l'ultima versione, 
visitare il sito http://www.excelswissknife.com 


Sommario
----------------------------
1. Cos'� Excel Swiss Knife
2. Installazione/Aggiornamento
3. Istruzioni per l'uso
4. Ringraziamenti
----------------------------


1. Cos'� Excel Swiss Knife
------------------------------------------------------------------------ 
Excel Swiss Knife (ESK) � un componente aggiuntivo per Microsoft Excel. 
Una volta installato, aggiunge al menu di Excel una nuova scheda, dalla 
quale si possono avviare tutte le sue funzioni. Queste sono divise in 
pi� categorie, e mirano a velocizzare compiti di elaborazione e 
trasformazione dei dati che manualmente o tramite le funzioni native di 
Excel richiederebbero molto tempo e numerosi passaggi, o in qualche caso 
non sarebbero possibili.
 
La scelta delle funzioni implementate viene da una lunga esperienza 
nell'elaborazione di basi dati in Excel, e dal continuo riproporsi delle 
stesse tediose operazioni per la pulizia e il riordino dei dati. Ho 
quindi deciso di prendere in mano la situazione e creare un set di 
strumenti che potessero facilitarmi il lavoro quotidiano. Ora metto 
questi strumenti a disposizione di tutti, sperando che possano essere 
utili a voi quanto lo sono a me! 

Continuer� a sviluppare nuove funzioni da aggiungere al programma, e 
sarei felicissimo di ricevere i vostri suggerimenti, che potete inviare 
direttamente all'indirizzo excelswissknife@gmail.com o collegandovi
al forum www.forumexcel.it, dove ESK ha un topic dedicato

ESK � gratuito per uso personale, e per ora disponibile in italiano e 
in inglese (con possibili imprecisioni). 
------------------------------------------------------------------------ 


2. Installazione e aggiornamento
------------------------------------------------------------------------ 
Trattandosi fondamentalmente di una collezione di macro in Visual Basic 
for Applications (VBA), prima dell'installazione � necessario abilitare 
l'esecuzione delle macro in Excel, e accettare l'eventuale richiesta di 
attivarle durante l'installazione. Garantisco ovviamente l'assenza di 
qualsiasi codice malevolo all'interno del programma. Occorre inoltre
chiudere tutte le istanze aperte di Excel prima di procedere.
------------------------------------------------------------------------ 


3. Istruzioni per l'uso
------------------------------------------------------------------------ 
Ogni funzione del programma ha le sue particolarit�, e va oltre gli 
scopi di questa breve presentazione lo scendere nei dettagli di ognuna 
di esse. Al sito http://www.excelswissknife.com sono pubblicate guide 
specifiche per ciascuna funzione. 

A titolo generale, prima di utilizzare le funzioni del programma, si 
sottolinea che � SEMPRE necessario effettuare un backup dei dati che si 
andranno a modificare, in quanto non � tecnicamente possibile invertire 
l'effetto delle macro del programma. Inoltre, in Excel l'esecuzione di 
una macro "distrugge" la coda di UNDO, perci� nella maggior parte dei 
casi NON SARA' POSSIBILE TORNARE ALLO STATO PRECEDENTE ALL'ESECUZIONE 
DELLA FUNZIONE. 

Per ovviare, almeno parzialmente, a questo rischio, tutte le funzioni 
"distruttive" del programma prevedono la creazione di un foglio di 
backup (nominato "Backup_ESK" e con la linguetta evidenziata in giallo). 
Quindi, se qualcosa va storto, sar� quanto meno possibile tornare alla 
situazione precedente all'ultima funzione eseguita, prendendo i dati dal 
foglio di backup. Tuttavia, il foglio di backup viene sovrascritto ogni 
volta, pertanto se si eseguono pi� funzioni consecutivamente, sar� 
sempre possibile tornare indietro SOLO RISPETTO ALL'ULTIMA ELABORAZIONE, 
mentre le precedenti sono ormai irreversibili, se non chiudendo il file 
senza salvarlo (e perdendo quindi ogni altra eventuale modifica 
effettuata). 
------------------------------------------------------------------------ 


4. Ringraziamenti
------------------------------------------------------------------------ 
Ringrazio per il supporto, l'aiuto e l'ispirazione: 
Pamela e Lisa; Roberto; i siti/forum: AsapUtilities.com, MrExcel, 
OzGrid, ForumExcel.it, StackOverflow, cpearson.com, andypope.info, 
rondebruin.nl, TuttoExcel.it e tutti gli altri siti gratuiti da cui ho 
attinto inestimabili informazioni e suggerimenti
------------------------------------------------------------------------ 













Thank you for downloading Excel Swiss Knife!
Below are some brief notes on the program and its use.
For any further information and to download the latest version,
visit http://www.excelswissknife.com


Summary
----------------------------
1. What is Excel Swiss Knife?
2. Installation/Update
3. User instructions
4. Thanks
----------------------------


1. What is Excel Swiss Knife?
------------------------------------------------------------------------
Excel Swiss Knife (ESK) is an add-in for Microsoft Excel.
Once installed, add a new tab to the Excel menu, from which you can 
start all its functions. These are divided into more categories, and aim 
to speed up processing tasks and data transformation either manually 
or through native functions of Excel would require a lot of time and 
numerous steps, or in some cases they would not be possible.
�
The choice of the implemented functions comes from a long experience
in the elaboration of data bases in Excel, and from the continuous 
repetition of the same tedious operations for cleaning and rearranging 
data. I have then decided to take the situation in my hand and create 
a set of tools that could make my daily work easier. Now I'm releasing 
these tools to everyone, hoping they can be useful to you as much 
as they are to me!

I will keep on developing new features to add to the program, e
I would be very happy to receive your suggestions, which you can send
directly to excelswissknife@gmail.com or by connecting
to the www.forumexcel.it forum (italian language), 
where ESK has a dedicated topic

ESK is free for personal use, and for now available in Italian and
English (the latter with possible inaccuracies).
------------------------------------------------------------------------


2. Installation and update
------------------------------------------------------------------------
Since this is basically a collection of macros in Visual Basic
for Applications (VBA), you must enable it before installation
execution of the macros in Excel, and accept any request for
activate them during installation. I obviously guarantee the absence of
any malicious code within the program. It is also necessary to
close all open Excel instances before proceeding.
------------------------------------------------------------------------


3. User instructions
------------------------------------------------------------------------
Every function of the program has its particularities, and goes beyond the
The purposes of this brief presentation to go down into the details of each one
of them. Guides with specifications for each function are published on
the extension's website http://www.excelswissknife.com.

Generally speaking, before using the functions of the program, I
stress that it is ALWAYS necessary to back up your data, as it is not 
technically possible to reverse the effect of a macro. 
Furthermore, in Excel the execution of a macro "destroys" the UNDO's stack, 
so in most of cases IT WILL NOT BE POSSIBLE TO RETURN TO THE STATE PREVIOUS 
TO THE EXECUTION OF THE FUNCTION.

To overcome, at least partially, this risk, all "destructive" functions
of the program provide for the creation of a backup sheet (named 
"ESK_Backup" and with the tab highlighted in yellow).
So if something goes wrong, it will be at least possible to get back to 
recover data before the last function was performed, taking it from the
backup sheet. However, the backup sheet is overwritten each
time, so if you perform multiple functions consecutively, it will be
always possible to go back ONLY BEFORE THE VERY LAST PROCESSING,
while the previous ones will be now irreversible, if not by closing the 
file without saving it (and thus losing any further modification
carried out).
------------------------------------------------------------------------


4. Thanks
------------------------------------------------------------------------
Thank you for your support, help and inspiration:
Pamela and Lisa; Roberto; web sites/forums: SQLBI, AsapUtilities.com, 
MrExcel, OzGrid, ForumExcel.it, StackOverflow, cpearson.com, andypope.info,
rondebruin.nl, TuttoExcel.it and all the other free sites from which I have
taken invaluable information and suggestions
------------------------------------------------------------------------